package Principal;

public class NenhumFuncionarioElegivelException extends Exception {
    public NenhumFuncionarioElegivelException(String mensagem) {
        super(mensagem);
    }
}

