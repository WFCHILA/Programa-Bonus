package Principal;

public class TabelaVaziaException extends Exception {
    public TabelaVaziaException(String mensagem) {
        super(mensagem);
    }
}

